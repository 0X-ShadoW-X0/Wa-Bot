/* # Exclusively from hisham ︻╦デ╤━╼

Youtube : https://youtube.com/c/ICHUTECH
 */

const Asena = require('../events');

const { MessageType, MessageOptions, Mimetype } = require('@adiwajshing/baileys');

const fs = require('fs');

const axios = require('axios');

const Config = require('../config');

const need = "Command Kazhinn Yanthankilum yazhuth muthe\nðŸ—¡ðŸ—¡"

if (Config.WORKTYPE == 'private') {

  Asena.addCommand({ pattern: 'cr7 ?(.*)', fromMe: true, dontAddCommandList: true }, (async (message, match) => {

    if (match[1] === '') return await message.sendMessage(need);

    var ttinullimage = await axios.get(`https://api.lolhuman.xyz/api/ephoto2/juventusshirt?apikey=queenamdipublic&text1=${encodeURIComponent(match[1])}&text2=7`, { responseType: 'arraybuffer' })

    await message.sendMessage(Buffer.from(ttinullimage.data), MessageType.image, { mimetype: Mimetype.jpg, caption: 'Made By Shadow' })

  }));

}

else if (Config.WORKTYPE == 'public') {

  Asena.addCommand({ pattern: 'cr7 ?(.*)', fromMe: false, dontAddCommandList: true }, (async (message, match) => {

    if (match[1] === '') return await message.sendMessage(need);

    var ttinullimage = await axios.get(`https://api.lolhuman.xyz/api/ephoto2/juventusshirt?apikey=queenamdipublic&text1=${encodeURIComponent(match[1])}&text2=7`, { responseType: 'arraybuffer' })

    await message.sendMessage(Buffer.from(ttinullimage.data), MessageType.image, { mimetype: Mimetype.jpg, caption: 'Made By Shadow' })

  }));

}
