/* Copyright (C) 2020 Yusuf Usta.

recodded by afnanplk

new work type by afnanplk

*/

const Asena = require('../events');

const {MessageType} = require('@adiwajshing/baileys');

const Config = require('../config');

const Language = require('../language');

const Lang = Language.getString('tagall');

const SLang = Language.getString('scrapers');

if (Config.WORKTYPE == 'private') {

async function checkImAdmin(message, user = message.client.user.jid) {

    var grup = await message.client.groupMetadata(message.jid);

    var sonuc = grup['participants'].map((member) => {

        if (member.jid.split('@')[0] === user.split('@')[0] && member.isAdmin) return true; else; return false;

    });

    return sonuc.includes(true);

}

Asena.addCommand({pattern: 'tagall ?(.*)', fromMe: true, dontAddCommandList: true, desc: Lang.TAGALL_DESC }, (async (message, match) => {

   

    if (!message.reply_message) {

        if (match[1] !== '') {

            grup = await message.client.groupMetadata(message.jid);

            var jids = [];

            mesaj = '';

            grup['participants'].map(

                async (uye) => {

                    mesaj += '@' + uye.id.split('@')[0] + ' ';

                    jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

                }

            );

            await message.client.sendMessage(message.jid,`${match[1]}`, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

        }

        else if (match[1] == '') {

            grup = await message.client.groupMetadata(message.jid);

            var jids = [];

            mesaj = '';

            grup['participants'].map(

                async (uye) => {

                    mesaj += '\n ▫️ @' + uye.id.split('@')[0] + 'ㅤ';

                    jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

                }

            );

            await message.client.sendMessage(message.jid, Config.TAGPLK + '\n ' + mesaj, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

        }

    }

    else if (message.reply_message) {

        grup = await message.client.groupMetadata(message.jid);

        var jids = [];

        mesaj = '';

        grup['participants'].map(

            async (uye) => {

                mesaj += '@' + uye.id.split('@')[0] + ' ';

                jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

            }

        );

        var tx = message.reply_message.text

        await message.client.sendMessage(message.jid,tx, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

    }

}));

}

else if (Config.WORKTYPE == 'public') {

    

  

    

    Asena.addCommand({pattern: 'tagall ?(.*)', fromMe: true, dontAddCommandList: true, desc: Lang.TAGALL_DESC }, (async (message, match) => {

        

    if (!message.reply_message) {

        if (match[1] !== '') {

            grup = await message.client.groupMetadata(message.jid);

            var jids = [];

            mesaj = '';

            grup['participants'].map(

                async (uye) => {

                    mesaj += '@' + uye.id.split('@')[0] + ' ';

                    jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

                }

            );

            await message.client.sendMessage(message.jid,`${match[1]}`, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

        }

        else if (match[1] == '') {

            grup = await message.client.groupMetadata(message.jid);

            var jids = [];

            mesaj = '';

            grup['participants'].map(

                async (uye) => {

                    mesaj += '\n ▫️ @' + uye.id.split('@')[0] + 'ㅤ';

                    jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

                }

            );

            await message.client.sendMessage(message.jid, Config.TAGPLK + '\n ' + mesaj, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

        }

    }

    else if (message.reply_message) {

        grup = await message.client.groupMetadata(message.jid);

        var jids = [];

        mesaj = '';

        grup['participants'].map(

            async (uye) => {

                mesaj += '@' + uye.id.split('@')[0] + ' ';

                jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

            }

        );

        var tx = message.reply_message.text

        await message.client.sendMessage(message.jid,tx, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

    }

}));

}

else if (Config.WORKTYPE == 'admin') {

    

    async function checkUsAdmin(message, user = message.data.participant) {

    var grup = await message.client.groupMetadata(message.jid);

    var sonuc = grup['participants'].map((member) => {     

        if (member.jid.split("@")[0] == user.split("@")[0] && member.isAdmin) return true; else; return false;

    });

    return sonuc.includes(true);

}

async function checkImAdmin(message, user = message.client.user.jid) {

    var grup = await message.client.groupMetadata(message.jid);

    var sonuc = grup['participants'].map((member) => {     

        if (member.jid.split("@")[0] == user.split("@")[0] && member.isAdmin) return true; else; return false;

    });

    return sonuc.includes(true);

}

    

    Asena.addCommand({pattern: 'tagall ?(.*)', fromMe: false, dontAddCommandList: true, desc: Lang.TAGALL_DESC }, (async (message, match) => {

         var us = await checkUsAdmin(message);

         if (!us) return await message.client.sendMessage(message.jid,Lang.PLKADMIN,MessageType.text ,{quoted: message.data });

   

    if (!message.reply_message) {

        if (match[1] !== '') {

            grup = await message.client.groupMetadata(message.jid);

            var jids = [];

            mesaj = '';

            grup['participants'].map(

                async (uye) => {

                    mesaj += '@' + uye.id.split('@')[0] + ' ';

                    jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

                }

            );

            await message.client.sendMessage(message.jid,`${match[1]}`, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

        }

        else if (match[1] == '') {

            grup = await message.client.groupMetadata(message.jid);

            var jids = [];

            mesaj = '';

            grup['participants'].map(

                async (uye) => {

                    mesaj += '\n ▫️ @' + uye.id.split('@')[0] + 'ㅤ';

                    jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

                }

            );

            await message.client.sendMessage(message.jid, Config.TAGPLK + '\n ' + mesaj, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

        }

    }

    else if (message.reply_message) {

        grup = await message.client.groupMetadata(message.jid);

        var jids = [];

        mesaj = '';

        grup['participants'].map(

            async (uye) => {

                mesaj += '@' + uye.id.split('@')[0] + ' ';

                jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

            }

        );

        var tx = message.reply_message.text

        await message.client.sendMessage(message.jid,tx, MessageType.extendedText, {contextInfo: {mentionedJid: jids}, previewType: 0})

    }

}));

    

     Asena.addCommand({pattern: 'report ?(.*)', fromMe: false, desc: 'to report someone'}, (async (message, match) => {

        if (match[1] == '') {

            let grup = await message.client.groupMetadata(message.jid);

            var jids = [];

            mesaj = '';

            grup['participants'].map(async (uye) => {

                if (uye.isAdmin) {

                    mesaj += '@' + uye.id.split('@')[0] + ' ';

                    jids.push(uye.jid);

                }

            });

           await message.client.sendMessage(message.jid,'ℝ𝔼ℙ𝕆ℝ𝕋 \n'+ mesaj , MessageType.extendedText, {quoted: message.data, contextInfo: {mentionedJid: jids}, previewType: 0})

        

        }

        else if (match[1] !== '' && message.reply_message) {

            let grup = await message.client.groupMetadata(message.jid);

            var jids = [];

            mesaj = '';

            grup['participants'].map(async (uye) => {

                if (uye.isAdmin) {

                    mesaj += '@' + uye.id.split('@')[0] + ' ';

                    jids.push(uye.id.replace('c.us', 's.whatsapp.net'));

                }

            });

            await message.client.sendMessage(message.jid,'ℝ𝔼ℙ𝕆ℝ𝕋\n' + mesaj  + '\n\nℝ𝔼𝔸𝕊𝕆ℕ :  ' + `${match[1]}`,  MessageType.extendedText, {quoted: message.data, contextInfo: {mentionedJid: jids}, previewType: 0})

        }

        else if (!message.reply_message) {

            return message.client.sendMessage(message.jid,'Please Respond to Users Message to Report', MessageType.text);

        }

}));

}
