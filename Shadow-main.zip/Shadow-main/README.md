<p align="center">
    <a href="https://github.com/SPARK-SHADOW">
        <img
            src="https://readme-typing-svg.herokuapp.com?size=30&width=800&lines=Welcome+To+Shadow-V2+BOT...+Codded+by+Shadow..."
            alt="Typing SVG"
        />
    </a>
</p>

<div align="center">
  <img border-radius: 15px src="https://avatars.githubusercontent.com/u/87223597?v=4" width="200" height="200"/>
  <p align="center">
<a href="#"><img title="Shadow" src="https://img.shields.io/badge/Shadow-pink?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
  <p align="center">
<a href="https://github.com/SPARK-SHADOW"><img title="Author" src="https://img.shields.io/badge/Author-Shadow-Shadow/Shadow?color=blue&style=for-the-badge&logo=whatsapp"></a>
</p>
</div>
<p align="center">
Project created by <a href="https://github.com/SPARK-SHADOW">Shadow</a> to make it public
    <br>
       | © |
        Reserved |
    <br> 
</p>

----

  <p align="center">
  <a href="https://github.com/SPARK-SHADOW/Shadow-V2 ">
    <img src="https://img.shields.io/github/repo-size/SPARK-SHADOW/Shadow-V2?color=green&label=Repo%20total%20size&style=plastic">
<p align="center">
<a href="https://github.com/SPARK-SHADOW/followers"><img title="Followers" src="https://img.shields.io/github/followers/SPARK-SHADOW?color=red&style=flat-circle"></a>
<a href="https://github.com/SPARK-SHADOW/Shadow-V2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/SPARK-SHADOW/Shadow-V2?color=red&style=flat-square"></a>
<a href="https://github.com/SPARK-SHADOW/Shadow-V2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/SPARK-SHADOW/Shadow-V2?color=red&style=flat-square"></a>
<a href="https://github.com/SPARK-SHADOW/Shadow-V2/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/SPARK-SHADOW/Shadow-V2?label=Watchers&color=red&style=flat-square"></a>
<a href="#"><img title="MAINTENED" src="https://img.shields.io/badge/UNMAINTENED-YES-blue.svg"</a>

```
  
WhatsAsena - Asena Userbot is Open Source software open to development. 
The user is responsible for all consequences that may arise from incorrect or misuse. 
Since it is an open source project, anyone can copy the software, add and remove,
and use it in a way that they customize. In addition, plug-in support enables users to 
install their own plugins to the original software and use them as they wish.
Using the bot out of purpose will explicitly ban you.
Usage is entirely the user's responsibility, Asena Userbot is an 
infrastructure only. Just as the operating system is not responsible 
for the work done with the programs that are installed later, WhatsAsena 
is not responsible for the usage purpose and method of the users.
Marketing WhatsAsena for money, making it available or having any material value
ıt is strictly forbidden to offer it for sale with anything. All legal investigations that may arise
the user is responsible.
```


## Setup
<div align="center">

  ### Simple Method
  
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://replit.com/@phaticusthiccy/WhatsAsena-QR)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/0XxShadoWxX0/Shadow)
     </div>
<br>
<br >
If Repl.it not working Try Termux for Qr scanning.Just Copy the Link Below in Termux
```
bash <(curl -L https://t.ly/tHxh)
``` 
<p>

----
    
   
<div align="center">
 <a href="#"><img title="Spark-Shadow" src="https://img.shields.io/badge/SPARK SHADOW-blue?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>

  
<div align="center">
    



    
<div align="center">
  <img border-radius: 15px src="https://i.imgur.com/aDZOvnl.jpeg" width="500" height="500"/> 

---


### ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, Asena executives do not accept responsibility.
By establishing the Asena, you are deemed to have accepted these responsibilities.
```

## Developer
  <div align="center">
    
  [![Spark-Shadow](https://camo.githubusercontent.com/9c184e56a76795eaeb8e7584424520de07a9aa4db57323f626ef9ff7730f62b9/68747470733a2f2f6d656469612e67697068792e636f6d2f6d656469612f34644d3155373661415133646245366263332f67697068792e676966?size=250)](https://github.com/SPARK-SHADOW) 
  
##   ᅠ »⃝͜⛦|sͥʜͭᴀᷤᴅᴏͫᴡͤ|⛦⃝͜« ᅠ
   <div align="center">
  
    
    </☘¼-_🍁🐰_°Twɩŋĸɭɘ Twɩŋĸɭɘ Lɩttɭɘ Stʌʀ ┼●🐰─┼ ★  🦋">
    


## License
This project is protected by `GNU General Public Licence v3.0` license.

### Disclaimer
`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark
