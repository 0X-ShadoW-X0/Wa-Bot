Takes gif data for plugins.
